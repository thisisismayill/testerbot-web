#!/bin/bash
# TesterBot - macOS tətbiqi (ikon) yaradır. Bir dəfə işlədilir.
#   bash setup-app.sh
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/Applications/TesterBot.app"
PYBIN="$(command -v python3 || echo /usr/bin/python3)"

echo "→ Qovluq : $DIR"
echo "→ Python : $PYBIN"

"$PYBIN" -c "import playwright" 2>/dev/null || {
  echo "!! playwright tapılmadı. Əvvəlcə: $PYBIN -m pip install -r '$DIR/requirements.txt'"; }

mkdir -p "$HOME/Applications"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>TesterBot</string>
  <key>CFBundleDisplayName</key><string>TesterBot</string>
  <key>CFBundleIdentifier</key><string>org.testerbot.ui</string>
  <key>CFBundleVersion</key><string>1.1</string>
  <key>CFBundleShortVersionString</key><string>1.1</string>
  <key>CFBundleExecutable</key><string>TesterBot</string>
  <key>CFBundleIconFile</key><string>TesterBot</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>10.13</string>
  <key>LSUIElement</key><true/>
</dict></plist>
PLIST

cat > "$APP/Contents/MacOS/TesterBot" <<LAUNCH
#!/bin/bash
# TesterBot başladıcı - serveri arxa planda işə salıb dərhal çıxır,
# beləcə ikona hər dəfə klikləyəndə brauzer yenidən açılır.
cd "$DIR" || exit 1
mkdir -p "\$HOME/Library/Logs"
nohup "$PYBIN" testerbot_ui.py >> "\$HOME/Library/Logs/TesterBot.log" 2>&1 &
exit 0
LAUNCH
chmod +x "$APP/Contents/MacOS/TesterBot"

# --- ikon ---
if [ -f "$DIR/assets/icon.png" ] && command -v iconutil >/dev/null 2>&1; then
  TMP="$(mktemp -d)"; SET="$TMP/TesterBot.iconset"; mkdir -p "$SET"
  for s in 16 32 128 256 512; do
    sips -z $s $s "$DIR/assets/icon.png" --out "$SET/icon_${s}x${s}.png" >/dev/null 2>&1 || true
    d=$((s * 2))
    sips -z $d $d "$DIR/assets/icon.png" --out "$SET/icon_${s}x${s}@2x.png" >/dev/null 2>&1 || true
  done
  iconutil -c icns "$SET" -o "$APP/Contents/Resources/TesterBot.icns" >/dev/null 2>&1 || true
  rm -rf "$TMP"
fi

# --- karantin bayraqlarını təmizlə (Gatekeeper bloklamasın) ---
xattr -cr "$DIR"  >/dev/null 2>&1 || true
xattr -cr "$APP"  >/dev/null 2>&1 || true
touch "$APP"

# --- Dock-a əlavə et ---
if [ "$1" != "--no-dock" ]; then
  if ! defaults read com.apple.dock persistent-apps 2>/dev/null | grep -q "TesterBot.app"; then
    defaults write com.apple.dock persistent-apps -array-add \
      "<dict><key>tile-data</key><dict><key>file-data</key><dict>\
<key>_CFURLString</key><string>$APP</string>\
<key>_CFURLStringType</key><integer>0</integer></dict></dict></dict>" 2>/dev/null || true
    killall Dock 2>/dev/null || true
    echo "→ Dock-a əlavə edildi"
  fi
fi

echo ""
echo "✓ Hazırdır: $APP"
echo "  Açmaq üçün: Dock-dakı TesterBot ikonu, və ya Cmd+Space → \"TesterBot\""
echo ""
open "$APP"
