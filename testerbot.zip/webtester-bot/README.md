# TesterBot — avtomatik sayt test botu

Linki verirsən, qalanını özü edir: saytı gəzir, tapdığı hər düyməyə klikləyir,
formaları test datası ilə doldurub göndərir, konsolu və şəbəkəni dinləyir və
sonda **ingiliscə HTML hesabat** + skrinşotlar + JSON verir.

Maaş istəmir, yorulmur, hər dəfə eyni ardıcıllıqla işləyir.

---

## Ən asan yol: düymə ilə işlətmək (terminal lazım deyil)

**`TesterBot.command`** faylına **iki dəfə klikləyin** (Windows-da `TesterBot.bat`).

Brauzerdə belə bir pəncərə açılacaq:

- yuxarıda **sayt ünvanı** üçün xana
- yanında **"Testi başlat"** düyməsi
- "Ayarlar" bölməsində: neçə səhifə gəzilsin, formalar göndərilsinmi, mobil yoxlansınmı və s.
- "Login arxasını da test et" bölməsində: istifadəçi adı, şifrə, login səhifəsi
- test gedərkən canlı jurnal, sonda isə **"Hesabatı aç"** düyməsi
- aşağıda əvvəlki bütün testlərin siyahısı

Şifrə yalnız sizin kompüterinizdə qalır, heç yerə göndərilmir.
Bağlamaq üçün açılan qara pəncərədə **Ctrl+C** basın.

> İlk dəfə `TesterBot.command` açılmırsa: sağ klik → **Open** → yenidən **Open** seçin.

Aşağıdakı bölmələr terminaldan istifadə etmək istəyənlər üçündür.

---

## Sayt kəşfiyyatı (yeni — v1.2)

Artıq TesterBot yalnız xətaları tapmır — hər audit edilən sayt üçün **kəşfiyyat** da toplayır və hesabatın yuxarısında göstərir:

- **Domen avtoritetliyi** — 0–10 skoru (OpenPageRank). Ahrefs-in “Domain Rating”-inə bənzər.
- **Performans** — Lighthouse balı + real istifadəçi göstəriciləri (LCP, INP, CLS, TTFB) — böyük alətlərin təkrar satdığı eyni Google datası.
- **Texnologiya stəki** — sayt hansı sistemlərlə qurulub (WordPress, React, Shopify, jQuery, Cloudflare və s.) — 7000+ texnologiya tanınır.
- **Hosting** — server, CDN, IP.

**Texnologiya və hosting açar tələb etmir — dərhal işləyir.** Avtoritet və performans üçün pulsuz açar lazımdır (bir dəfə):

| Nə üçün | Haradan | Pulsuz limit |
|---|---|---|
| Domen avtoritetliyi | [domcop.com/openpagerank](https://www.domcop.com/openpagerank/) → qeydiyyat → açar | 30 000 domen / ay |
| Performans (limiti artırır) | [Google PageSpeed API](https://developers.google.com/speed/docs/insights/v5/get-started) | performans açarsız da işləyir |

Açarları interfeysdə **“Kəşfiyyat açarları”** bölməsinə bir dəfə yapışdırırsınız — yalnız sizin kompüterinizdə saxlanılır. Terminal ilə: `--opr-key` / `--psi-key`, və ya `TESTERBOT_OPR_KEY` / `TESTERBOT_PSI_KEY` mühit dəyişənləri. Söndürmək: `--no-intel` (hamısı) və ya `--no-perf` (yalnız performans, ən yavaş hissə).

---

## Link qrafı (yeni — v1.3) — öz data anbarımızın toxumu

Bu, Ahrefs-in özəyi ilə **eyni məntiqdir**, kiçik miqyasda: bot saytı gəzərkən hər linki qeydə alır, sonra **öz PageRank-ımızı** hesablayır (Google-un və Ahrefs-in istifadə etdiyi eyni power-iteration alqoritmi).

Hesabatda görəcəksiniz:

- **Ən güclü səhifələr** — saytın daxili link strukturuna görə hansı səhifə ən "avtoritetlidir". **Orfan səhifələri** (heç bir daxili link göstərməyən) də aşkarlayır — SEO üçün əsl problem.
- **Xaricə link verilən domenlər** — saytınız kimə link verir, neçə dəfə, nofollow olub-olmadığı ilə.
- **Xam data** — `linkgraph.json` (tam edge siyahısı + hesablamalar) və `linkgraph-edges.csv`. Bu, əsl, açıla bilən **datasetdir** — sadəcə qrafik yox.

Açar tələb etmir, dərhal işləyir. Söndürmək lazım deyil — hər gəzişdə avtomatik toplanır.

**Niyə vacibdir:** bu, "açıq internetı gəzib öz data anbarımızı qurmaq" yolunun ilk addımıdır. İndi bir saytın daxili qrafını qururuq; eyni məntiqlə çoxlu saytı gəzsək, domenlər-arası qraf — yəni əsl backlink indeksi — yaranır.

---

## İndeks rejimi (v2.0) — öz backlink indeksimiz + öz Domain Authority-miz

Bura qədər bot **bir** saytı test edirdi. İndi **çoxlu** saytı bir yerdə gəzib
aralarındakı linkləri toplayır və **öz Domain Authority metrikimizi** hesablayır —
heç bir üçüncü tərəf, heç bir açar yoxdur. Bu, Ahrefs-in özəyidir (backlink indeksi +
domen reytinqi), bir maşının tuta biləcəyi miqyasda.

**Necə işləyir:**

İnterfeysdə yuxarıda **“Çoxlu sayt · İndeks”** rejiminə keçin, domenləri hər sətirdə
bir yazın, **“İndeks qur”** basın. Terminal ilə:

```bash
python3 tb_index.py sayt-1.com sayt-2.com reqib-3.com
python3 tb_index.py --seeds domenler.txt --max-pages 30
```

**Nə alırsınız:**

- **Domain Authority reytinqi** — hər domen 1–100 skor. Domenlər-arası link qrafı
  üzərində PageRank + referring-domain sayı qarışığı (Ahrefs DR, Moz DA ilə eyni prinsip).
- **Backlink kəşfi** — istənilən domenə klikləyin: ona kim link verir, hansı anchor
  mətnlə, follow/nofollow. Referring domenlər öz avtoritetlərinə görə sıralanır.
- **Link Intersect · fürsətlər** — “sizin domeniniz”i seçin, indeks sizə deyil, **rəqiblərinizə**
  link verən domenləri göstərir, neçə rəqibə link verdiyinə görə sıralanmış. Bunlar ən dəyərli
  backlink fürsətləridir (Ahrefs-in “Link Intersect” funksiyası, öz datamızdan).
- **Böyüyən indeks** — hər dəfə işlədəndə data `testerbot-index.db` (SQLite) faylında
  toplanır və artır. Bir saytı təkrar crawl etmək linkləri yeniləyir, təkrarlamır.
- **Xam data** — `index-report/index-data.json` və SQLite bazası birbaşa açıla bilər.


**Məsuliyyətli crawl (mühüm):** İndeks rejimi standart olaraq **robots.txt-ə hörmət edir**,
özünü dürüst təqdim edir (`TesterBotIndex/2.0`) və səhifələr arasında nəzakətli fasilə verir.
Araşdırmanın göstərdiyi kimi, bloklanmayan, “yaxşı bot” olmaq bir link-məhsulunun ən böyük
struktur üstünlüyüdür. Yalnız öz saytınızı crawl edirsinizsə və robots.txt sizə mane olursa:
`--ignore-robots`. Fasiləni dəyişmək: `--delay 800` (ms).

**Vacib:** avtoritet metriki nə qədər çox sayt crawl etsəniz, bir o qədər dəqiq olur —
çünki qraf böyüyür. Bir neçə rəqib saytı bir yerdə crawl edəndə real mənzərə çıxır.
Yalnız icazəniz olan saytları crawl edin.

---

## 1. Quraşdırma (bir dəfəlik)

Kompüterində **Python 3.9+** olmalıdır (`python3 --version` ilə yoxla).

**macOS / Linux:**
```bash
cd webtester-bot
./install.sh
```

**Windows:**
```
install.bat   (üstünə iki dəfə klik)
```

Skript iki şey edir: Python paketlərini quraşdırır və Chromium brauzerini yükləyir
(~150 MB, yalnız bir dəfə). Əl ilə etmək istəsən:

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

---

## 2. İlk işlətmə

```bash
python3 tester_bot.py https://sizin-sayt.az
```

Bitəndə terminalda qısa xülasə görəcəksən, tam hesabat isə buradadır:

```
testerbot-report/report.html      ← brauzerdə aç
testerbot-report/report.json      ← proqramla oxumaq üçün
testerbot-report/screenshots/     ← sübut şəkilləri
```

Hesabatda hər problem **Critical / High / Medium / Low / Info** kimi
qruplaşdırılır, üstünə klikləyəndə açılır: nə olub, hansı səhifədə, hansı
elementdə, sübut (şəbəkə cavabı, xəta mətni, skrinşot) və **təklif olunan həll**.

---

## 3. Login arxasını test etmək

Şifrəni əmr sətrində yazmamaq üçün mühit dəyişənindən istifadə et:

```bash
export TESTERBOT_PASS='test-hesabin-sifresi'          # Windows: set TESTERBOT_PASS=...

python3 tester_bot.py https://sizin-sayt.az \
  --login-url https://sizin-sayt.az/login \
  --username test@sizin-sayt.az \
  --login-success-url /dashboard \
  --extra-url https://sizin-sayt.az/dashboard \
  --extra-url https://sizin-sayt.az/profile
```

- Bot login formasını özü tapmağa çalışır. Tapmasa `--user-selector`,
  `--pass-selector`, `--submit-selector` ilə göstər.
- `--login-success-url` və ya `--login-success-text` girişin doğrudan alındığını
  təsdiqləyir. Giriş alınmasa bot bunu **Critical** problem kimi qeyd edir.
- Bot `/logout`, `/signout` linklərinə girmir ki, sessiya itməsin. Yenə də itsə,
  avtomatik yenidən daxil olur.
- Sessiyanı saxlayıb sonra təkrar işlətmək:
  `--save-storage-state session.json`, sonrakı dəfə `--storage-state session.json`.

> **Vacib:** yalnız TEST hesabı ver, real müştəri hesabı yox.

---

## 4. Bot nəyi yoxlayır

**Səhifə səviyyəsində**
- Uncaught JavaScript xətaları və `console.error` mesajları
- HTTP 4xx / 5xx cavablar (həm səhifənin özü, həm arxa plandakı API çağırışları)
- Yüklənməyən şəkillər, uğursuz şəbəkə sorğuları
- Boş və ya demək olar boş səhifələr
- İstifadəçiyə görünən "zibil" mətn: `undefined`, `NaN`, `[object Object]`,
  `lorem ipsum`, `{{template}}`, `TODO:`, server xəta izləri

**Linklər**
- Bütün daxili və xarici linklər tək-tək yoxlanır (sınıq link, 404, 500, əlçatmaz host)
- Naməlum URL-in 404 yox, 200 qaytarması (soft-404)
- Təkrarlanan `<title>`-lar

**Kliklər**
- Hər düymə, tab, akkordeon, dropdown, modal açan element sınanır
- Klikdən sonra JS xətası, 5xx cavab, 404 API çağırışı varsa qeyd olunur
- **Ölü düymələr**: klikləyəndə URL, DOM, şəbəkə — heç nə dəyişmirsə
- Örtülü/klikləmək mümkün olmayan elementlər (z-index, overlay problemləri)

**Formalar**
- Boş göndəriş: brauzer bloklayırmı? Bloklayırsa, **serverdə də yoxlama var mı**
  (bot brauzer yoxlamasını söndürüb serverə eyni boş sorğunu göndərir)
- Səhv formatlı e-poçt qəbul olunurmu
- Düzgün datalarla göndəriş: işləyirmi, 5xx qaytarırmı, ya heç nə etmirmi
- **Çıxışın escape olunması**: bot `<b>…</b>` mətni göndərir; səhifə onu real HTML
  kimi göstərirsə, bu ciddi problemdir (XSS riski)
- Login forması uydurma məlumatları qəbul edirmi (kritik), səhv şifrəyə xəta
  mesajı verirmi

**Mobil / responsiv**
- 390px (telefon) və 820px (planşet) ölçüsündə üfüqi sürüşmə (horizontal scroll)
- Viewport meta tegi yoxdursa
- Hansı elementin daşdığını da göstərir + skrinşot

**Əlçatanlıq (accessibility)**
- Deque-in **axe-core** mühərriki (WCAG 2.1 A/AA) — daxilə yığılıb, internet lazım deyil
- Əlavə olaraq: `alt`-sız şəkillər, etiketsiz sahələr, adı olmayan düymələr,
  `lang` atributu, başlıq iyerarxiyası, təkrar `id`-lər

**Performans**
- Yüklənmə vaxtı, TTFB (server cavab müddəti), səhifə ağırlığı, sorğu sayı, DOM ölçüsü

**Təhlükəsizlik gigiyenası (yalnız sizin öz domeninizdə)**
- HTTPS var mı, HTTP → HTTPS yönləndirməsi işləyirmi
- Mixed content, `target=_blank` + `rel=noopener`
- Çatışmayan başlıqlar: CSP, X-Frame-Options, X-Content-Type-Options, HSTS, Referrer-Policy
- Səhvən açıq qalmış fayllar: `/.env`, `/.git/config`, `/backup.sql`, `/phpinfo.php` və s.

**SEO / metadata**
- `<title>`, meta description, `h1`, canonical, Open Graph, favicon, robots.txt, sitemap.xml,
  təsadüfən qalmış `noindex`

---

## 5. Təhlükəsizlik: bot nəyə toxunmur

Standart rejimdə bot **silmə, ödəniş, hesab bağlama, çıxış** kimi görünən
düymələrə **klikləmir** və belə formaları göndərmir (həm ingiliscə, həm
azərbaycanca, həm rusca sözlər tanınır). Toxunmadıqlarını hesabatda "Skipped"
kimi göstərir ki, bilə-bilə buraxıldığını görəsən.

Hər şeyi, o cümlədən təhlükəli düymələri sınamaq istəyirsənsə:

```bash
python3 tester_bot.py https://staging.sizin-sayt.az --danger-mode
```

⚠️ `--danger-mode` **yalnız test/staging kopyasında** işlədilməlidir — real
saytda datanı silə bilər.

Botu yalnız **öz saytında** və ya yazılı icazən olan saytda işlət.

---

## 6. Faydalı əmrlər

```bash
# Daha geniş gəzsin
python3 tester_bot.py https://sayt.az --max-pages 150 --max-depth 4

# Brauzeri görünən şəkildə işlət (nə etdiyini seyr et)
python3 tester_bot.py https://sayt.az --headed --slow-mo 400

# Yalnız bloqu test et
python3 tester_bot.py https://sayt.az --include "/blog/"

# Admin panelinə girmə
python3 tester_bot.py https://sayt.az --exclude "/admin" --exclude "\?export="

# Heç nəyə klikləmə, forma göndərmə (ən təhlükəsiz rejim)
python3 tester_bot.py https://sayt.az --no-click --no-forms

# SPA (React/Vue/Angular) yavaş açılırsa
python3 tester_bot.py https://sayt.az --settle 3000 --nav-timeout 60000

# Konfiqurasiya faylı ilə
python3 tester_bot.py --config config.example.yaml

# CI/CD: kritik problem varsa build-i sındır
python3 tester_bot.py https://sayt.az --fail-on critical
```

Bütün açarların siyahısı: `python3 tester_bot.py --help`

---

## 7. Botu özün sınamaq (qəsdən xətalı sayt)

Paketdə içində **20-dən çox qəsdən qoyulmuş xəta** olan kiçik test saytı var.
Botun nə tapdığını görmək üçün:

```bash
# 1-ci terminal
python3 testsite/server.py

# 2-ci terminal
python3 tester_bot.py http://localhost:8099 \
  --login-url http://localhost:8099/login \
  --username tester --password secret123 \
  --login-success-url /dashboard \
  --extra-url http://localhost:8099/dashboard
```

Hesabatda sınıq linkləri, JS xətalarını, ölü düyməni, escape olunmamış çıxışı,
serverdə yoxlaması olmayan formanı, mobil daşmanı və s. görəcəksən.

---

## 8. Tez-tez qarşılaşılan hallar

| Problem | Həll |
|---|---|
| `playwright: command not found` | `python -m playwright install chromium` |
| Sayt çox yavaşdır, timeout olur | `--nav-timeout 90000 --settle 3000` |
| Staging-də self-signed sertifikat | `--ignore-https-errors` |
| Login tapılmır | `--login-url` + `--user-selector` / `--pass-selector` verin |
| Hesabat çox "Low/Info" ilə doludur | Hesabatda **Critical** və ya **High** xanasına klikləyin — yalnız onlar qalır |
| Bot çox uzun çəkir | `--max-pages 25 --no-external-links --no-axe` |
| Formaların göndərilməsini istəmirəm | `--no-forms` |

---

## 9. Fayl strukturu

```
webtester-bot/
├── TesterBot.command       # ← iki dəfə klikləyin (macOS interfeys)
├── TesterBot.bat           # ← Windows üçün eyni
├── testerbot_ui.py         # interfeysin serveri
├── ui_page.py              # interfeysin səhifəsi
├── tester_bot.py           # tək sayt QA (CLI)
├── tb_index.py             # çoxlu sayt indeks (CLI)
├── reports/                # interfeyslə edilən testlərin hesabatları
├── requirements.txt
├── install.sh / install.bat
├── config.example.yaml
├── testsite/server.py      # qəsdən xətalı nümunə sayt
└── testerbot/
    ├── crawler.py          # gəzmə + orkestrasiya
    ├── auth.py             # login
    ├── dom_probe.py        # səhifədən məlumat yığan JS
    ├── audits.py           # DOM/şəbəkə/konsol yoxlamaları
    ├── interact.py         # klikləmə + forma testləri
    ├── site.py             # robots, sitemap, 404, linklər, açıq fayllar
    ├── a11y.py             # axe-core auditi
    ├── intelligence.py     # avtoritet + performans + hosting
    ├── techdetect.py       # texnologiya aşkarı (7000+ imza)
    ├── linkgraph.py        # tək-sayt link qrafı + PageRank
    ├── index_store.py      # böyüyən link indeksi (SQLite)
    ├── authority.py        # öz Domain Authority metrikimiz
    ├── harvest.py          # sürətli çoxlu-sayt link crawler
    ├── index_report.py     # İndeks Explorer paneli
    ├── robots.py           # robots.txt + nəzakətli crawl
    ├── report.py           # HTML + JSON hesabat
    └── vendor/
        ├── axe.min.js      # axe-core (MPL-2.0, Deque Systems)
        └── techfp.json     # texnologiya imzaları (MIT)
```

Əlavə yoxlama əlavə etmək asandır: `audits.py`-də yeni funksiya yazıb
`Finding(...)` qaytarmaq kifayətdir — hesabata özü düşəcək.

---

## 10. Yaddan çıxarma

Bot **insan testçini əvəz etmir** — o, təkrarlanan, mexaniki hissəni götürür:
hər səhifəni gəzmək, hər düyməni sınamaq, hər linki yoxlamaq. Biznes məntiqinin
düzgünlüyünü (məsələn "endirim düzgün hesablanırmı") hələ də insan yoxlamalıdır.

Hesabatdakı hər tapıntını "təsdiqlənmiş bug" kimi yox, "baxılmalı nöqtə" kimi qəbul et.
