#!/usr/bin/env bash
# TesterBot quraşdırma (macOS / Linux)
set -e
cd "$(dirname "$0")"
echo "→ Python paketləri quraşdırılır…"
python3 -m pip install -r requirements.txt
echo "→ Chromium brauzeri yüklənir (bir dəfəlik, ~150 MB)…"
python3 -m playwright install chromium
echo ""
chmod +x TesterBot.command 2>/dev/null
xattr -d com.apple.quarantine TesterBot.command 2>/dev/null
echo "✓ Hazırdır."
echo ""
echo "  Ən asan yol:  TesterBot.command faylına iki dəfə klikləyin"
echo "  Terminal ilə: python3 tester_bot.py https://sizin-sayt.az"
