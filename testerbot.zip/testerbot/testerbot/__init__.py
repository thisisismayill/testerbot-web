"""TesterBot - autonomous website QA crawler."""
__version__ = "2.3.0"
