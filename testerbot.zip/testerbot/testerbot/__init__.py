"""TesterBot - autonomous website QA crawler."""
__version__ = "2.4.2"
